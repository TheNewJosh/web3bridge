<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
<link rel="apple-touch-icon" sizes="180x180" href="http://www.mains-sync.com/apple-touch-icon.html">
<link rel="icon" type="image/png" sizes="32x32" href="http://www.mains-sync.com/favicon-32x32.html">
<link rel="icon" type="image/png" sizes="16x16" href="http://www.mains-sync.com/favicon-16x16.html">
<link rel="manifest" href="http://www.mains-sync.com/site.html"><?php /**PATH C:\wamp64\www\web3bridge.io\web3bridges\web3bridge\resources\views/layouts/meta.blade.php ENDPATH**/ ?>